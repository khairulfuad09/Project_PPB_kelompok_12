package com.example.loginfirebase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class PilihanMateri_Siswa extends AppCompatActivity {
    private CardView btn1, btn2, btn3, btn4, btn5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pilihan_materi);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PilihanMateri_Siswa.this, "Halaman Materi Perangkat Masukkan", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), PerangkatMasukkan_Siswa.class));
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PilihanMateri_Siswa.this, "Halaman Materi Pemroses", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), Pemroses_Siswa.class));
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PilihanMateri_Siswa.this, "Halaman Materi Alat Output", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), AlatOutput_Siswa.class));
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PilihanMateri_Siswa.this, "Halaman Materi Peranti Penyimpanan Sekunder", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), PenyimpananSekunder_Siswa.class));
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PilihanMateri_Siswa.this, "Halaman Materi Peranti Lainnya", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), Peranti_Siswa.class));
            }
        });
    }
}