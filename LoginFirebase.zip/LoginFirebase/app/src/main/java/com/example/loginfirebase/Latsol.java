package com.example.loginfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Latsol extends AppCompatActivity {
    TextView kuis;
    RadioGroup rg;
    RadioButton PilihanA, PilihanB, PilihanC, PilihanD;
    int nomor = 0;
    public static int hasil, benar, salah;

    // Pertanyaan
    String[] soal_kuis = new String[] {
            "Komponen (elemen) utama sistem komputer yang secara fisik dapat dilihat, dipegang dan dipindahkan disebut ….",
            "Agar perangkat keras komputer dapat berfungsi diperlukan ….",
            "Perangkat keras komputer yang berfungsi untuk mengeluarkan hasil pemrosesan dan pengolahan data disebut ….",
            "Memori komputer yang berfungsi untuk menyimpan sementara perintah dan data pada saat sebuah program dijalankan disebut ….",
            "Bagian dari sebuah komputer yang mempunyai fungsi sebagai pusat pengolahan data dan pengontrolan kerja komputer adalah ….",
            "Media penyimpanan data yang kapasitasnya cukup besar, akses datanya juga relatif cepat serta mudah dibawa kemana – mana dan handal adalah … .",
            "Papan induk (papan elektronik) yang dilengkapi jalur-jalur koneksi yang memungkinkan perangkat-perangkat komputer berkomunikasi satu dengan yang lainnya dan merupakan tempat bergantungnya semua perangkat keras komputer disebut … .",
            "Perangkat keras yang digunakan untuk mendeteksi kode baris yang terdapat pada sebuah barang saat kita melakukan transaksi di toko atau supermarket sehingga akan diketahui nilai harganya disebut … .",
            "Perangkat keras komputer yang berfungsi mengubah sinyal digital menjadi sinyal suara dinamakan … ",
            "Perangkat keras komputer yang berhubungan dengan kualitas gambar dan tampilan di layar monitor adalah ...."
    };

    // Pilihan Jawaban
    String[] pilihan_jawaban = new String[] {
            "Mainware", "Hardware", "Brainware", "Sotfware",
            "Perangkat lunak", "Perangkat keluaran", "Perangkat masukan", "Perangkat tambahan",
            "Output Device", "Peripheral Device", "Input Device", "Storage Device",
            "Memori", "Harddisk", "RAM", "ROM",
            "Memori", "RAM", "Hard disk", "Processor",
            "Harddisk Internal", "CD-ROM", "Flash disk", "DVD",
            "CPU", "LAN Card", "Memory Card", "Motherboard",
            "Card Reader", "Barcode Reader", "Barcode Digital", "Barcode Scanner",
            "VGA Card", "Network Card", "Sound Card", "Memory Card",
            "VGA Card", "Network Card", "Sound Card", "Memory Card",
    };

    // Jawaban
    String[] jawaban = new String[] {
            "Hardware",
            "Perangkat lunak",
            "Output Device",
            "RAM",
            "Processor",
            "Flash disk",
            "Motherboard",
            "Barcode Reader",
            "Sound Card",
            "VGA Card",
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_latsol);

        kuis = findViewById(R.id.kuis);
        rg = findViewById(R.id.pilihan);
        PilihanA = findViewById(R.id.pilihanA);
        PilihanB = findViewById(R.id.pilihanB);
        PilihanC = findViewById(R.id.pilihanC);
        PilihanD = findViewById(R.id.pilihanD);

        kuis.setText(soal_kuis[nomor]);
        PilihanA.setText(pilihan_jawaban[0]);
        PilihanB.setText(pilihan_jawaban[1]);
        PilihanC.setText(pilihan_jawaban[2]);
        PilihanD.setText(pilihan_jawaban[3]);

        rg.check(0);
        benar = 0;
        salah = 0;
    }
    public void next (View view) {
        if (PilihanA.isChecked() || PilihanB.isChecked() || PilihanC.isChecked() || PilihanD.isChecked()){
            RadioButton jawaban_user = findViewById(rg.getCheckedRadioButtonId());
            String ambil_jawaban_user = jawaban_user.getText().toString();
            rg.check(0);
            if (ambil_jawaban_user.equalsIgnoreCase(jawaban[nomor])) benar++;
            else salah++;
            nomor++;
            if (nomor < soal_kuis.length) {
                kuis.setText(soal_kuis[nomor]);
                PilihanA.setText(pilihan_jawaban[(nomor * 4) + 0]);
                PilihanB.setText(pilihan_jawaban[(nomor * 4) + 1]);
                PilihanC.setText(pilihan_jawaban[(nomor * 4) + 2]);
                PilihanD.setText(pilihan_jawaban[(nomor * 4) + 3]);
            }else {
                hasil = benar * 10;
                Intent selesai = new Intent(getApplicationContext(), HasilKuis.class);
                startActivity(selesai);
            }
        }
        else {
            Toast.makeText(this, "Lengkapi Jawaban Terlebih Dahulu", Toast.LENGTH_SHORT).show();
        }
    }
}