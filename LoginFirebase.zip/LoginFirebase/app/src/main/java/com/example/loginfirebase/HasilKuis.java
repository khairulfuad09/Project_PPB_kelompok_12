package com.example.loginfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HasilKuis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_kuis);

        TextView hasil = findViewById(R.id.hasil);
        TextView nilai = findViewById(R.id.nilai);

        hasil.setText("Jawaban benar : "+ Latsol.benar+"\nJawaban salah : "+ Latsol.salah);
        nilai.setText(""+ Latsol.hasil);
    }
    public void ulangi(View view) {
        finish();
        Intent ulang = new Intent(getApplicationContext(), Latsol.class);
        startActivity(ulang);
    }
    public void kembali(View view) {
        finish();
        Intent kembali = new Intent(getApplicationContext(), Dashboard_Siswa.class);
        startActivity(kembali);
    }
}