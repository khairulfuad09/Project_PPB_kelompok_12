package com.example.loginfirebase;

public class PerangkatMasukkanModel {
    String key, subbab, uraian, image;

    public PerangkatMasukkanModel() {
        // dibutuhkan oleh Firebase
    }

    public PerangkatMasukkanModel(String key, String subbab, String uraian) {
        this.key = key;
        this.subbab = subbab;
        this.uraian = uraian;

    }
    public void setImage(String Image) {
        this.image = Image;
    }

    public String getImage() {
        return image;
    }

    public void setKey(String key){
        this.key = key;
    }

    public String getkey() {
        return key;
    }

    public String getSubbab() {
        return subbab;
    }

    public String getUraian() {
        return uraian;
    }


}
